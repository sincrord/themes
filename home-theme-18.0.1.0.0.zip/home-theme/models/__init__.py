# -*- coding: utf-8 -*-

from . import ir_ui_menu
from . import res_config_settings
from . import home_app_sequence
