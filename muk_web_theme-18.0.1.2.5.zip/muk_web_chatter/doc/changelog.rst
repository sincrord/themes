`1.2.0`
-------

- Hide Notifications

`1.1.0`
-------

- Resize Chatter


`1.0.0`
-------

- Initial Release
