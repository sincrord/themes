import { Component } from "@odoo/owl";

export class WidgetAnnouncement extends Component {}

WidgetAnnouncement.template = "main_menu.WidgetAnnouncement";
